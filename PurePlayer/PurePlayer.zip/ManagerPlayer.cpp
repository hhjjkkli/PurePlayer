#include "ManagerPlayer.h"

SDL_Event ManagerPlayer::event;
bool ManagerPlayer::isRunning = false;
SDL_Renderer *ManagerPlayer::renderer = nullptr;
SDL_Texture *ManagerPlayer::texture = nullptr;
struct SwsContext *ManagerPlayer::img_convert_ctx = nullptr;
struct SwrContext *ManagerPlayer::swr_ctx = nullptr;
AVStream *ManagerPlayer::streamOfAudio = nullptr;
AVStream *ManagerPlayer::streamOfVideo = nullptr;
SDL_Window *ManagerPlayer::window = nullptr;

ManagerPlayer::ManagerPlayer()
{

}

void ManagerPlayer::init(const std::string file_path, char * title, int xpos, int ypos, int width, int height, bool fullscreen)
{
	if (file_path.empty())
	{
		return;
	}
	this->file_path = av_strdup(file_path.c_str());
	av_register_all();
	avformat_network_init();

	this->videoPlayer = new VideoPlayer();
	this->audioPlayer = new AudioPlayer();
	this->subtitlePlayer = new SubtitlePlayer();

	int flags = SDL_WINDOW_FOREIGN;
	if (fullscreen)
	{
		flags = SDL_WINDOW_FULLSCREEN;
	}
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
	{
		logd("Subsystem Initialised!");

		window = SDL_CreateWindow(title, xpos, ypos, width, height, flags);
		if (window)
		{
			logd("Window created!");
		}

		renderer = SDL_CreateRenderer(window, -1, 0);
		if (renderer)
		{
			logd("Renderer created!");
		}

		isRunning = true;
	}
	else
	{
		isRunning = false;
	}

	std::thread read_thread(&ManagerPlayer::read_file, this);
	read_thread.detach();
}

void ManagerPlayer::handleEvent()
{
	SDL_PollEvent(&event);
	switch (event.type) {
	case SDL_QUIT:
		isRunning = false;
		break;
	case SDL_KEYDOWN:
		switch (event.key.keysym.sym) {
		case SDLK_ESCAPE:
		case SDLK_q:
			isRunning = false;
			break;
		}
	default:
		break;
	}
}

void ManagerPlayer::update()
{
}

void ManagerPlayer::render()
{
	SDL_RenderClear(renderer);
	//draw texture
	SDL_RenderPresent(renderer);
}

void ManagerPlayer::clean()
{
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_Quit();
	logd("Game cleaned!");
}

void ManagerPlayer::read_file()
{
	int i, ret;

	AVPacket *pkt = (AVPacket *)av_malloc(sizeof(AVPacket));
	if (pkt == NULL)
	{
		return;
	}

	this->format_ctx = avformat_alloc_context();
	if (!this->format_ctx)
	{
		return;
	}
	ret = avformat_open_input(&this->format_ctx, this->file_path, NULL, NULL);
	if (ret < 0)
	{
		return;
	}

	for (i = 0; i < this->format_ctx->nb_streams; i++)
	{
		if (this->format_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			this->stream_index[AVMEDIA_TYPE_VIDEO] = i;
			read_stream(i);
		}
		else if (this->format_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_AUDIO)
		{
			this->stream_index[AVMEDIA_TYPE_AUDIO] = i;
			read_stream(i);
		}
		else if (this->format_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_SUBTITLE)
		{
			this->stream_index[AVMEDIA_TYPE_SUBTITLE] = i;
			read_stream(i);
		}
	}
	if (this->stream_index[AVMEDIA_TYPE_AUDIO] < 0 &&
		this->stream_index[AVMEDIA_TYPE_VIDEO] < 0)
	{
		logd("Do not have any data in the file");
		return;
	}

	while (true)
	{
		if (true == this->abort_request)
		{
			break;
		}
		if (true == this->pause_request)
		{
			player_pause();
		}
		if (true == this->seek_request)
		{
			player_seek();
		}
		ret = av_read_frame(this->format_ctx, pkt);
		if (ret < 0)
		{
			if ((ret == AVERROR_EOF || avio_feof(format_ctx->pb)) && false == this->eof)
			{
				if (this->stream_index[AVMEDIA_TYPE_VIDEO] >= 0)
					this->videoPlayer->videoDecoder.pkt_queue.put_nullpacket();
				if (this->stream_index[AVMEDIA_TYPE_AUDIO] >= 0)
					this->audioPlayer->audioDecoder.pkt_queue.put_nullpacket();
				this->eof = true;
			}
			if (this->format_ctx->pb && this->format_ctx->pb->error)
				break;
		}
		else
		{
			eof = 0;
		}
		
		if (pkt->stream_index == this->stream_index[AVMEDIA_TYPE_AUDIO])
		{
			if (audioPlayer->audioDecoder.pkt_queue.put_packet(pkt) < 0)
			{
				break;
			}
		}
		else if (pkt->stream_index == this->stream_index[AVMEDIA_TYPE_VIDEO])
		{
			if (videoPlayer->videoDecoder.pkt_queue.put_packet(pkt) < 0)
			{
				break;
			}
		}
		else if (pkt->stream_index == this->stream_index[AVMEDIA_TYPE_SUBTITLE])
		{
			if (subtitlePlayer->subtitleDecoder.pkt_queue.put_packet(pkt) < 0)
			{
				break;
			}
		}
		else
		{
			av_packet_unref(pkt);
		}
	}
}

int ManagerPlayer::read_stream(int stream_num) {
	int ret = 0;
	if (stream_num < 0 || stream_num >= format_ctx->nb_streams)
		return -1;
	AVCodecContext *avctx;
	AVCodec *codec;
	avctx = avcodec_alloc_context3(NULL);
	if (!avctx)
		return -2;

	ret = avcodec_parameters_to_context(avctx, this->format_ctx->streams[stream_num]->codecpar);
	if (ret < 0) {
		avcodec_free_context(&avctx);
		return -3;
	}
	av_codec_set_pkt_timebase(avctx, format_ctx->streams[stream_num]->time_base);
	codec = avcodec_find_decoder(avctx->codec_id);
	avctx->codec_id = codec->id;
	this->eof = 0;
	format_ctx->streams[stream_num]->discard = AVDISCARD_DEFAULT;
	ret = avcodec_open2(avctx, codec, NULL);
	if (ret < 0) {
		avcodec_free_context(&avctx);
		return ret;
	}
	switch (avctx->codec_type) {
	case AVMEDIA_TYPE_AUDIO:
		this->swr_ctx = swr_alloc();
		this->swr_ctx = swr_alloc_set_opts(swr_ctx, AV_CH_LAYOUT_STEREO,
			AV_SAMPLE_FMT_S16, avctx->sample_rate,
			av_get_default_channel_layout(avctx->channels), avctx->sample_fmt, avctx->sample_rate,
			0, NULL);
		if (!swr_ctx || swr_init(swr_ctx) < 0) {
			swr_free(&swr_ctx);
			return -1;
		}
		this->streamOfAudio = format_ctx->streams[stream_num];
		this->audioPlayer->audioDecoder.init(avctx);
		this->audioPlayer->audioDecoder.start_decode_thread();
		break;
	case AVMEDIA_TYPE_VIDEO:
		this->streamOfVideo = format_ctx->streams[stream_num];
		ManagerPlayer::img_convert_ctx = sws_getContext(avctx->width, avctx->height, avctx->pix_fmt,
			avctx->width, avctx->height, AV_PIX_FMT_YUV420P, SWS_BICUBIC, NULL, NULL, NULL);
		this->videoPlayer->videoDecoder.init(avctx);
		this->videoPlayer->videoDecoder.start_decode_thread();
		break;	
	case AVMEDIA_TYPE_SUBTITLE:
		break;
	default:
		break;
	}
	logd("Player.open_stream --> Player.change_state(PlayerState::READY)");
	change_state(PlayerState::READY);
	return ret;
}

void ManagerPlayer::change_state(PlayerState state)
{
	std::unique_lock<std::mutex> lock(mutex);
	if (state == PlayerState::READY)
	{
		if (this->audioPlayer->audioDecoder.avctx != NULL && this->videoPlayer->videoDecoder.avctx != NULL)
		{
			this->state = state;
		}
	}
	else
	{
		this->state = state;
	}
	state_condition.notify_all();
}

void ManagerPlayer::togglePause()
{
	std::unique_lock<std::mutex> lock(mutex);
	this->pause_request = !this->pause_request;
}

void ManagerPlayer::player_pause()
{
	av_read_pause(this->format_ctx);
}

void ManagerPlayer::toggleSeek(int64_t seekTo)
{
	this->seek_request = true;
	this->seek_timestamp = seekTo;
}

void ManagerPlayer::player_seek()
{
	int ret = av_seek_frame(format_ctx, -1, this->seek_timestamp * AV_TIME_BASE, 1);
	if (ret < 0)
	{
		logd("Error: av_seek_frame()");
	}
	else
	{
		if (this->stream_index[AVMEDIA_TYPE_VIDEO] >= 0) {
			this->videoPlayer->videoDecoder.pkt_queue.flush();
		}
		if (this->stream_index[AVMEDIA_TYPE_AUDIO] >= 0) {
			this->audioPlayer->audioDecoder.pkt_queue.flush();
		}
	}
	this->seek_request = false;
	this->eof = 0;
}

double ManagerPlayer::get_duration() {
	if (this->format_ctx != nullptr) {
		return this->format_ctx->duration / 1000000.0;
	}
}

void ManagerPlayer::wait_state(PlayerState need_state) {
	std::unique_lock<std::mutex> lock(mutex);
	state_condition.wait(lock, [this, need_state] {
		return this->state >= need_state;
	});
}
