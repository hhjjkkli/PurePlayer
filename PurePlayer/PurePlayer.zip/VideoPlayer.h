#pragma once
#include "BasePlayer.h"
#include "VideoDecoder.h"
int show_frame_sdl(void *managerPlayer);
class VideoPlayer: public BasePlayer
{
public:
	VideoPlayer();
	~VideoPlayer();
	void play_current_frame();

	bool get_img_frame(AVFrame * frame);

	VideoDecoder videoDecoder;
private:
	
};
