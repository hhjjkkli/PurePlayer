#include <SDL.h>
#include <Windows.h>
#include "log.h"
#include "ManagerPlayer.h"
#include "AudioPlayer.h"
#include "VideoPlayer.h"
#pragma warning(disable: 4819)
#pragma warning(disable: 4996)

int WINAPI WinMain(
	HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine,
	int       nCmdShow
)
{
	logc((char*)"");
	ManagerPlayer *managerOfPlayer = new ManagerPlayer();

	managerOfPlayer->init("DreamItPossible.mp4", (char*)"Pure Media Player", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 800, 640, false);
	managerOfPlayer->wait_state(PlayerState::READY);
	std::thread audioThread(play_audio_sdl, (void*)managerOfPlayer);
	std::thread videoThread(show_frame_sdl, (void*)managerOfPlayer);
	audioThread.join();
	videoThread.join();

	while (managerOfPlayer->running()) 
	{
		managerOfPlayer->handleEvent();
		//if(It's time to go next frame of video) {
		managerOfPlayer->update();
		managerOfPlayer->render();
		//}
	}

	managerOfPlayer->clean();

	return 0;
}