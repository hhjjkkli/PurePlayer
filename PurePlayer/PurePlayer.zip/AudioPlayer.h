#pragma once
#include "BasePlayer.h"
#include "AudioDecoder.h"
#include "ManagerPlayer.h"
int play_audio_sdl(void *managerPlayer);
class AudioPlayer:public BasePlayer
{
public:
	AudioPlayer();
	~AudioPlayer();
	void play_current_frame(void * managerPlayer);
	void play_current_frame() {};
	bool get_aud_buffer(uint8_t * outputBuffer);

	AudioDecoder audioDecoder;
private:
};

