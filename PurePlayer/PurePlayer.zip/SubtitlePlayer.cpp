#include "SubtitlePlayer.h"

SubtitlePlayer::SubtitlePlayer()
{
}


SubtitlePlayer::~SubtitlePlayer()
{
}

void SubtitlePlayer::play_current_frame()
{

}
