#pragma once
class ProgressBar
{
public:
	ProgressBar();
	~ProgressBar();
};

