#include "VideoPlayer.h"
#include "ManagerPlayer.h"

VideoPlayer::VideoPlayer()
{
}


VideoPlayer::~VideoPlayer()
{
}

void VideoPlayer::play_current_frame()
{
}

bool VideoPlayer::get_img_frame(AVFrame *frame) {
	logd("VideoPlayer::get_img_frame(): I am in get_img_frame()");
	if (frame == nullptr) {
		logd("Player.get_img_frame: frame is null");
		return false;
	}
	auto av_frame = videoDecoder.frame_queue.get_frame();
	logd("Player.get_img_frame: got a frame from viddec.frame_queue.get_frame()");
	logd("Player.get_img_frame: framesize=%d", videoDecoder.frame_queue.get_size());
	sws_scale(ManagerPlayer::img_convert_ctx, (const uint8_t* const*)av_frame->frame->data, av_frame->frame->linesize, 0, videoDecoder.avctx->height,
		frame->data, frame->linesize);
	double timestamp = av_frame_get_best_effort_timestamp(av_frame->frame)*av_q2d(ManagerPlayer::streamOfVideo->time_base);

	double time_wait = av_gettime_relative() + av_frame->duration;
	logd("Player.get_img_frame: timestamp=%lf, duration=%lf", timestamp, av_frame->duration);

	while (av_gettime_relative() < time_wait) {
		logd("Player.get_img_frame: wait clock");
	}
	av_frame_free(&av_frame->frame);
	return true;
}

int show_frame_sdl(void *managerPlayer) {
	ManagerPlayer *mPlayer = (ManagerPlayer*)managerPlayer;
	mPlayer->wait_state(PlayerState::READY);

	AVFrame *frameYUV = av_frame_alloc();
	int numBytes = av_image_get_buffer_size(AV_PIX_FMT_YUV420P, mPlayer->videoPlayer->videoDecoder.get_width(), mPlayer->videoPlayer->videoDecoder.get_height(), 1);
	logd("VideoPlayer::show_frame_sdl(): numBytes=%d", numBytes);
	uint8_t *OutBuffer = (uint8_t *)av_malloc(numBytes * sizeof(uint8_t));
	av_image_fill_arrays(frameYUV->data, frameYUV->linesize, OutBuffer, AV_PIX_FMT_YUV420P, mPlayer->videoPlayer->videoDecoder.get_width(), mPlayer->videoPlayer->videoDecoder.get_height(), 1);

	SDL_SetWindowSize(ManagerPlayer::window, mPlayer->videoPlayer->videoDecoder.get_width(), mPlayer->videoPlayer->videoDecoder.get_height());

	ManagerPlayer::texture = SDL_CreateTexture(ManagerPlayer::renderer, SDL_PIXELFORMAT_IYUV, SDL_TEXTUREACCESS_STREAMING,
		mPlayer->videoPlayer->videoDecoder.get_width(), mPlayer->videoPlayer->videoDecoder.get_height());

	logd("VideoPlayer.show_frame_sdl(): next into a loop of get_img_frame()");
	while (mPlayer->videoPlayer->get_img_frame(frameYUV)) {
		if (mPlayer->pause_request) {
			//
		}
		logd("VideoPlayer.show_frame_sdl(): next SDL_UpdateTexture(),framesize=%d", mPlayer->videoPlayer->videoDecoder.frame_queue.get_size());

		SDL_RenderClear(ManagerPlayer::renderer);

		SDL_UpdateTexture(ManagerPlayer::texture, NULL, frameYUV->data[0], frameYUV->linesize[0]);
		SDL_RenderCopy(ManagerPlayer::renderer, ManagerPlayer::texture, NULL, NULL);
		SDL_RenderPresent(ManagerPlayer::renderer);
	}

	return 0;
}
