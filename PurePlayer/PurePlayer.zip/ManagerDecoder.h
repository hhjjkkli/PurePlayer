#pragma once
class ManagerDecoder
{
public:
	ManagerDecoder();
	~ManagerDecoder();
};

