#include "AudioPlayer.h"
#include "ManagerPlayer.h"
#pragma warning(disable: 4996)

Uint32 audio_len = 0;
Uint8 *audio_pos = NULL;
Uint8 *audio_chunk = NULL;

void callback_audio(void *udata, Uint8 *stream, int len)
{
	SDL_memset(stream, 0, len);
	if (audio_len == 0) {
		return;
	}
	len = (len>audio_len ? audio_len : len);
	SDL_MixAudio(stream, audio_pos, len, SDL_MIX_MAXVOLUME);
	audio_pos += len;
	audio_len -= len;
}

int play_audio_sdl(void *managerPlayer)
{
	ManagerPlayer *mPlayer = (ManagerPlayer*)managerPlayer;
	mPlayer->wait_state(PlayerState::READY);

	AVSampleFormat out_sample_fmt = AV_SAMPLE_FMT_S16;
	uint8_t *out_buffer;
	int nextSize;
	int out_buffer_size = av_samples_get_buffer_size(NULL, mPlayer->audioPlayer->audioDecoder.avctx->channels, mPlayer->audioPlayer->audioDecoder.avctx->frame_size, out_sample_fmt, 1);
	out_buffer = (uint8_t*)av_malloc(out_buffer_size);

	SDL_AudioSpec wanted_spec;

	wanted_spec.freq = mPlayer->audioPlayer->audioDecoder.avctx->sample_rate;
	wanted_spec.format = AUDIO_S16SYS;
	wanted_spec.channels = mPlayer->audioPlayer->audioDecoder.avctx->channels;
	wanted_spec.silence = 0;
	wanted_spec.samples = mPlayer->audioPlayer->audioDecoder.avctx->frame_size;
	wanted_spec.callback = callback_audio;
	wanted_spec.userdata = mPlayer->audioPlayer->audioDecoder.avctx;
	logd("before SDL_OpenAudio: format is S16SYS=%d, freq=%d, channels=%d, samples=%d", wanted_spec.format == AUDIO_S16SYS, wanted_spec.freq, wanted_spec.channels, wanted_spec.samples);

	if (SDL_OpenAudio(&wanted_spec, NULL)<0) {
		logd("SDL_OpenAudio() error");
		return 0;
	}
	logd("after SDL_OpenAudio: format is S16SYS=%d, freq=%d, channels=%d, samples=%d", wanted_spec.format == AUDIO_S16SYS, wanted_spec.freq, wanted_spec.channels, wanted_spec.samples);

	bool start = false;
	while (mPlayer->audioPlayer->get_aud_buffer(out_buffer)) {
		while (audio_len>0) {
			SDL_Delay(1);
		}

		audio_chunk = (Uint8 *)out_buffer;
		audio_len = out_buffer_size;
		audio_pos = audio_chunk;
		logd("main.play_audio_sdl(): audio_len = %d, audio_pos = %lld", audio_len, audio_pos);

		if (start == false) {
			logd("SDL_PauseAudio(0)");
			SDL_PauseAudio(0);
			start = true;
		}
	}

	return 0;
}

AudioPlayer::AudioPlayer()
{
}

AudioPlayer::~AudioPlayer()
{
}

void AudioPlayer::play_current_frame(void *managerPlayer)
{
	play_audio_sdl(managerPlayer);
}

bool AudioPlayer::get_aud_buffer(uint8_t *outputBuffer) {
	if (outputBuffer == nullptr) return false;
	auto av_frame = this->audioDecoder.frame_queue.get_frame();

	av_samples_get_buffer_size(NULL, this->audioDecoder.avctx->channels, this->audioDecoder.avctx->frame_size, this->audioDecoder.avctx->sample_fmt, 1);

	int ret = swr_convert(ManagerPlayer::swr_ctx, &outputBuffer, this->audioDecoder.avctx->frame_size,
		(uint8_t const **)(av_frame->frame->extended_data),
		av_frame->frame->nb_samples);
	double timestamp = av_frame->frame->pkt_pts * av_q2d(ManagerPlayer::streamOfAudio->time_base);

	double time_wait = av_gettime_relative() + av_frame->duration;
	logd("AudioPlayer::get_aud_buffer(): timestamp=%lf, duration=%lf", timestamp, av_frame->duration);
	while (av_gettime_relative() < time_wait) {
		logd("AudioPlayer::get_aud_buffer(): wait clock");
	}
	av_frame_free(&av_frame->frame);

	return ret >= 0;
}
