#include "ManagerDecoder.h"



ManagerDecoder::ManagerDecoder()
{
}


ManagerDecoder::~ManagerDecoder()
{
}
