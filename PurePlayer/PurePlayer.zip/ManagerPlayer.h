#pragma once
#include <SDL.h>
#include "VideoPlayer.h"
#include "AudioPlayer.h"
#include "SubtitlePlayer.h"
#include "log.h"
class AudioPlayer;

class ManagerPlayer
{
public:
	ManagerPlayer();
	void init(const std::string file_path, char * title, int xpos, int ypos, int width, int height, bool fullscreen);
	~ManagerPlayer() {};

	void handleEvent();
	void update();
	void render();
	void clean();

	void read_file();

	int read_stream(int stream_index);

	void change_state(PlayerState state);

	void togglePause();

	void player_pause();

	void toggleSeek(int64_t seekTo);

	void player_seek();

	double get_duration();

	void wait_state(PlayerState need_state);

	bool running() {
		return isRunning;
	}

	static SDL_Renderer *renderer;
	static SDL_Texture *texture;
	static SDL_Event event;
	static bool isRunning;

	char *file_path;
	AVFormatContext *format_ctx;

	bool abort_request = false;
	bool seek_request = false;
	bool pause_request = false;
	bool eof = false;

	PlayerState state = PlayerState::UNKNOWN;	

	static SDL_Window *window;
	static struct SwsContext *img_convert_ctx;
	static struct SwrContext *swr_ctx;
	static AVStream *streamOfAudio;
	static AVStream *streamOfVideo;
	int stream_index[AVMEDIA_TYPE_NB] = { -1 };
	AVCodecContext *avctx;
	AVCodec *codec;
	VideoPlayer *videoPlayer;
	AudioPlayer *audioPlayer;
	SubtitlePlayer *subtitlePlayer;
	int64_t seek_timestamp = 0;
private:
	int64_t timestamp_player = 0;

	std::mutex mutex;
	std::condition_variable state_condition;
};