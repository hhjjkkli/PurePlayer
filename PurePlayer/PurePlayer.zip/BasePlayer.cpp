#include "BasePlayer.h"



BasePlayer::BasePlayer()
{
}


BasePlayer::~BasePlayer()
{
}
